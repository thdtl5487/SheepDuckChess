export interface GameLogDTO{
    game_serial_number: string;
    white_player: number;
    black_player: number;
    win: string;
    game_log: string[];
}